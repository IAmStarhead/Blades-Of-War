Blades Of War — showcase of Adam, Eve and the well

To view:
1. Extract this ZIP archive.
2. Open BladesOfWar_Showcase.html in a current desktop browser (Chrome, Edge, Firefox or Safari).
3. If the browser blocks local files, start a local server in this folder:
   python -m http.server 8000
   Then open http://localhost:8000/BladesOfWar_Showcase.html

The showcase is self-contained; both GLB files are also included separately in
assets/models/. The stone well was not modified in this recovery pass.
