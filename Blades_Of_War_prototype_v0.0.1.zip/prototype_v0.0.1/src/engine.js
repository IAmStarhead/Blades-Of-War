/* ============================================================
   GAME ENGINE v0.0.1 — Дус-проект Роберта Сабирова
   Центральное хранилище состояния и игровая логика.
   ============================================================ */

const GameEngine = (function () {
  // --- Внутреннее состояние ---
  let state = {};
  let version = "0.0.1";

  // --- Константы ---
  const LOCATIONS = {
    market: { name: "Рыночная площадь", type: "market", x: 0, y: 0 },
    tavern: { name: "Трактир 'Тихий угол'", type: "tavern", x: 1, y: 0 },
    outskirts: { name: "Окраины Новиграда", type: "wilderness", x: -1, y: 0 },
    forest_edge: { name: "Опушка леса", type: "wilderness", x: 0, y: -1 }
  };

  // --- Инициализация ---
  function init() {
    state = {
      version,
      time: {
        hour: 8,
        day: 1,
        month: 1,
        year: 1024,
        tickRate: "normal" // normal, fast, paused
      },
      player: {
        id: "player_01",
        name: "Роберт",
        age: 27,
        gender: "male",
        faction: null,
        status: "free",
        memory: [], // { date, text, emotion, subject }
        relationships: {}, // id -> score (-100..100)
        skills: {
          combat: 15,
          trade: 20,
          survival: 25,
          medicine: 10,
          leadership: 5
        },
        needs: {
          health: 85,
          hunger: 70,
          fatigue: 60,
          mood: 65
        },
        inventory: [
          { id: "item_bread", name: "Черствый хлеб", value: 2, weight: 0.5, type: "food" },
          { id: "item_coin", name: "Медная монета", value: 1, weight: 0.01, type: "currency", qty: 15 },
          { id: "item_knife", name: "Обычный нож", value: 12, weight: 0.3, type: "weapon" }
        ],
        money: 15,
        location: "tavern",
        equipped: { weapon: null, armor: null }
      },
      npcs: [
        createNPC("n_01", "Мара", 34, "female", "Травница и целительница. Спокойная, осторожная. Не верит в ведьм, но боится слухов.", { medicine: 40, survival: 30, trade: 10 }, { health: 80, hunger: 65, fatigue: 50, mood: 55 }, "tavern"),
        createNPC("n_02", "Горн", 42, "male", "Бывший солдат, теперь торговец кожей. Жёсткий, но справедливый. Не любит дезертиров.", { combat: 45, trade: 35, survival: 20, leadership: 30 }, { health: 75, hunger: 60, fatigue: 55, mood: 40 }, "market"),
        createNPC("n_03", "Сельма", 19, "female", "Дочь кузнеца. Любопытная, легко поддаётся влиянию. Мечтает уйти из Новиграда.", { survival: 15, trade: 5, medicine: 5, leadership: 5 }, { health: 90, hunger: 80, fatigue: 40, mood: 75 }, "market"),
        createNPC("n_04", "Варн", 56, "male", "Старый охотник на окраинах. Необщительный, но знает лес. Может быть полезен или опасен.", { combat: 35, survival: 55, trade: 15, medicine: 20 }, { health: 65, hunger: 70, fatigue: 45, mood: 35 }, "forest_edge")
      ],
      faction: {
        id: "f_01",
        name: "Братство Пепла",
        type: "religious_order",
        description: "Орден религиозных следователей. Ищет еретиков, допросы проводит строго, но не все члены фанатики.",
        leader: null, // назначим позже или оставим для игрока
        reputation: {}, // playerId -> score
        members: ["n_01"], // пока только Мара как связанная (она целительница под подозрением)
        status: "active"
      },
      world: {
        locations: LOCATIONS,
        settlement: {
          name: "Новиград",
          population: 340,
          resources: { food: 120, wood: 80, ore: 20 },
          laws: {
            slavery: "prohibited",
            heresy: "investigated",
            violence: "punished"
          },
          marketPrices: {
            bread: 3,
            knife: 15,
            herbs: 25
          }
        }
      },
      events: {
        log: [], // { time, text, type }
        activeFlags: []
      },
      journal: []
    };

    // Связи NPC с миром
    state.player.relationships = {
      "n_01": 0,
      "n_02": 5,
      "n_03": -5,
      "n_04": -15
    };

    state.faction.reputation = { "player_01": 0 };

    // Память игрока об NPC
    state.player.memory.push({ date: { hour: 8, day: 1, month: 1, year: 1024 }, text: "Прибыл в Новиград. Пахнет дымом и свежим хлебом.", emotion: "neutral", subject: "world" });
  }

  function createNPC(id, name, age, gender, bio, skills, needs, location) {
    return {
      id, name, age, gender, bio,
      skills,
      needs,
      status: "free",
      faction: null,
      location,
      memory: [{ date: { hour: 8, day: 1, month: 1, year: 1024 }, text: "Живу в этом мире.", emotion: "neutral", subject: "self" }],
      relationships: {},
      inventory: []
    };
  }

  // --- Утилиты времени ---
  function formatTime() {
    const t = state.time;
    const seasons = ["Зима", "Весна", "Лето", "Осень"];
    const season = seasons[Math.floor((t.month - 1) / 3) % 4];
    return `День ${t.day}, ${season}, ${t.year} г. ${t.hour}:00`;
  }

  function advanceTime(hours) {
    const t = state.time;
    t.hour += hours;
    while (t.hour >= 24) { t.hour -= 24; t.day += 1; }
    while (t.day > 30) { t.day -= 30; t.month += 1; }
    while (t.month > 12) { t.month -= 12; t.year += 1; }

    // Обновление потребностей (простое)
    updateNeeds();
  }

  function updateNeeds() {
    const p = state.player;
    // Каждые несколько часов потребности снижаются
    p.needs.hunger = Math.max(0, p.needs.hunger - 3);
    p.needs.fatigue = Math.max(0, p.needs.fatigue - 2);
    p.needs.health = Math.max(0, p.needs.health - 0.5);
    p.needs.mood = Math.max(0, Math.min(100, p.needs.mood - 1));

    // Если очень голоден — здоровье падает быстрее
    if (p.needs.hunger < 20) p.needs.health -= 2;
    if (p.needs.fatigue < 20) p.needs.mood -= 5;
  }

  // --- События ---
  function generateEvent() {
    const events = [
      { text: "В трактире обсуждают странный шум в лесу. Кто-то упоминает 'Братство Пепла'.", type: "rumor", target: "faction" },
      { text: "Мара выглядит напряжённой. Она шепчет, что сегодня ночью будут обыски.", type: "warning", target: "npc_n_01" },
      { text: "Горн предлагает купить свежую кожу по хорошей цене. Он явно хочет быстро продать товар.", type: "trade", target: "npc_n_02" },
      { text: "Ветер принёс запах дыма с окраин. Похоже, кто-то разжёг костёр в лесу.", type: "environment", target: "world" },
      { text: "Сельма спрашивает, не хотите ли вы помочь ей с покупками. Она кажется искренней.", type: "request", target: "npc_n_03" }
    ];
    const evt = events[Math.floor(Math.random() * events.length)];
    state.events.log.push({ time: {...state.time}, text: evt.text, type: evt.type, target: evt.target });
    state.journal.push({ time: {...state.time}, entry: evt.text });
  }

  // --- Взаимодействие с NPC ---
  function talkToNPC(npcId) {
    const npc = state.npcs.find(n => n.id === npcId);
    if (!npc) return "Никого нет.";

    const relation = state.player.relationships[npcId] || 0;
    let text = `Вы говорите с ${npc.name}. `;
    text += `Она кажется ${relation > 20 ? "дружелюбной" : relation < -20 ? "враждебной" : "осторожной"}. `;

    // Простая память: если уже говорили несколько раз — текст меняется
    const prevTalks = (npc.memory || []).filter(m => m.subject === "player_talk").length;
    if (prevTalks === 0) {
      text += npc.bio;
      npc.memory.push({ date: {...state.time}, text: `Говорил с ${state.player.name}.`, emotion: (relation > 0 ? "positive" : "neutral"), subject: "player_talk" });
      state.player.memory.push({ date: {...state.time}, text: `Познакомился с ${npc.name}.`, emotion: "neutral", subject: npcId });
    } else {
      text += "Она помнит ваш прошлый разговор.";
    }
    return text;
  }

  // --- Торговля ---
  function sellItem(itemId, qty = 1) {
    const idx = state.player.inventory.findIndex(i => i.id === itemId);
    if (idx === -1) return { success: false, message: "У вас нет этого предмета." };

    const item = state.player.inventory[idx];
    const price = Math.floor((item.value || 5) * 0.7); // продаём дешевле
    const total = price * qty;

    state.player.money += total;
    if (qty >= (item.qty || 1)) {
      state.player.inventory.splice(idx, 1);
    } else {
      item.qty = (item.qty || 1) - qty;
    }

    state.events.log.push({ time: {...state.time}, text: `Продано: ${item.name} за ${total} монет.`, type: "trade" });
    return { success: true, message: `Продано за ${total} монет.`, item: item.name, total };
  }

  function buyItem(itemName) {
    const prices = state.world.settlement.marketPrices;
    if (!prices[itemName]) return { success: false, message: "Товар недоступен." };

    const price = prices[itemName];
    if (state.player.money < price) return { success: false, message: "Недостаточно денег." };

    state.player.money -= price;
    const newItem = { id: "item_" + itemName, name: itemName === "bread" ? "Свежий хлеб" : itemName === "knife" ? "Новый нож" : itemName, value: price, weight: itemName === "bread" ? 0.5 : 0.3, type: itemName === "bread" ? "food" : "weapon" };
    state.player.inventory.push(newItem);

    return { success: true, message: `Куплено: ${newItem.name} за ${price} монет.`, item: newItem.name, price };
  }

  // --- Движение ---
  function moveTo(locationKey) {
    if (!LOCATIONS[locationKey]) return { success: false, message: "Место неизвестно." };
    state.player.location = locationKey;
    state.time.hour += 1;
    advanceTime(1);
    generateEvent(); // случайное событие при перемещении
    return { success: true, message: `Вы прибыли в ${LOCATIONS[locationKey].name}.`, location: LOCATIONS[locationKey].name };
  }

  // --- Питание и отдых ---
  function eatFood() {
    const foodItem = state.player.inventory.find(i => i.type === "food");
    if (!foodItem) return { success: false, message: "У вас нет еды." };
    state.player.needs.hunger = Math.min(100, state.player.needs.hunger + 30);
    state.player.needs.mood = Math.min(100, state.player.needs.mood + 10);
    const qty = foodItem.qty || 1;
    if (qty > 1) foodItem.qty -= 1; else state.player.inventory = state.player.inventory.filter(i => i.id !== foodItem.id);
    return { success: true, message: "Вы поели. Голод уменьшился." };
  }

  function rest() {
    state.time.hour += 4;
    advanceTime(4);
    state.player.needs.fatigue = Math.min(100, state.player.needs.fatigue + 40);
    state.player.needs.health = Math.min(100, state.player.needs.health + 10);
    return { success: true, message: "Вы отдохнули. Усталость снижена." };
  }

  // --- Сохранение ---
  function saveToString() {
    const data = {
      version: state.version,
      timestamp: Date.now(),
      data: JSON.parse(JSON.stringify(state))
    };
    return JSON.stringify(data);
  }

  function loadFromString(str) {
    try {
      const saved = JSON.parse(str);
      if (saved.version !== state.version) {
        console.warn("Версия сохранения отличается от текущей. Возможна частичная потеря данных.");
      }
      state = saved.data;
      return true;
    } catch (e) {
      console.error("Ошибка загрузки:", e);
      return false;
    }
  }

  // --- Публичный API ---
  return {
    init,
    getState: () => JSON.parse(JSON.stringify(state)),
    getTimeStr: () => formatTime(),
    getTimeState: () => ({...state.time}),
    getPlayer: () => ({...state.player, inventory: [...state.player.inventory], memory: [...state.player.memory]}),
    getNPC: (id) => {
      const n = state.npcs.find(x => x.id === id);
      return n ? {...n, memory: [...n.memory], inventory: [...n.inventory]} : null;
    },
    getAllNPCs: () => [...state.npcs],
    getFaction: () => ({...state.faction, reputation: {...state.faction.reputation}}),
    getEvents: () => [...state.events.log],
    getJournal: () => [...state.journal],
    talk: talkToNPC,
    move: moveTo,
    eat: eatFood,
    rest: rest,
    sell: sellItem,
    buy: buyItem,
    generateEvent,
    saveString: saveToString,
    loadString: loadFromString,
    updateNeeds,
    getLocationInfo: (key) => LOCATIONS[key] ? {...LOCATIONS[key]} : null,
    getWorldInfo: () => ({...state.world})
  };
})();

// Экспорт для браузера и тестов
if (typeof window !== "undefined") {
  window.GameEngine = GameEngine;
}
if (typeof global !== "undefined") {
  global.GameEngine = GameEngine;
}
