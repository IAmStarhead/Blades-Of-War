/* ============================================================
   DATA INIT v0.0.1
   Начальная настройка мира при загрузке страницы.
   ============================================================ */

function initGameData() {
  GameEngine.init();
  
  // Добавляем стартовые события в лог
  const startEvents = [
    "Вы просыпаетесь в Новиграде. Воздух пахнет дымом и свежим хлебом.",
    "Братство Пепла ведёт расследование. Некоторые жители боятся, другие поддерживают их."
  ];
  
  startEvents.forEach(text => {
    const evt = { time: GameEngine.getTimeState(), text, type: "start" };
    GameEngine.getState().events.log.push(evt);
  });
  
  // Начальная запись журнала
  GameEngine.getState().journal.push({
    time: GameEngine.getTimeState(),
    entry: "Прибытие в Новиград. Одиночество, но и свобода."
  });
}
